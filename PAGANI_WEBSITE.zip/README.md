# 🏎️ Pagani Zonda R - Scrollytelling Showcase

A premium, award-worthy scrollytelling website showcasing the legendary **Pagani Zonda R** track hypercar. Built with cutting-edge web technologies to deliver a cinematic, scroll-controlled experience.

## ✨ Features

- **Scroll-Controlled Image Sequence**: 240 frames of a rotating Pagani Zonda R synchronized to scroll position
- **HUD-Style Text Overlay**: Three distinct phases (Hero → Design → Engine) that transition based on scroll progress
- **High-DPI Canvas Rendering**: Retina/4K display support with `devicePixelRatio` scaling
- **Premium Animations**: Framer Motion for buttery-smooth transitions and micro-interactions
- **Italian Luxury Aesthetic**: Gold accents, glassmorphism, and sci-fi inspired UI
- **Fully Responsive**: Optimized for all screen sizes from mobile to 4K displays

## 🛠️ Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **Animation**: Framer Motion
- **Fonts**: Orbitron (headings) & Rajdhani (body) from Google Fonts

## 🚀 Getting Started

### Prerequisites

Make sure you have Node.js installed (v18 or higher recommended).

### Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
npm start
```

## 📁 Project Structure

```
PAGANI WEBSITE/
├── app/
│   ├── layout.tsx          # Root layout with fonts
│   ├── page.tsx            # Main orchestrator (600vh scroll container)
│   └── globals.css         # Tailwind theme & global styles
├── components/
│   ├── Navbar.tsx          # Glassmorphism navbar
│   ├── ZondaScrollCanvas.tsx   # High-DPI canvas renderer
│   ├── ZondaExperience.tsx     # HUD overlay with 3 phases
│   ├── SpecsGrid.tsx       # Technical specifications
│   ├── Features.tsx        # Key features grid
│   └── Footer.tsx          # Premium footer
├── data/
│   └── carData.ts          # All content and copy
├── PAGANI FRAMES/          # 240 car rotation frames
│   ├── ezgif-frame-001.jpg
│   ├── ezgif-frame-002.jpg
│   └── ... (240 total)
└── public/                 # Static assets
```

## 🎨 Design Philosophy

- **Premium First**: Every interaction feels luxurious and intentional
- **Performance Obsessed**: Optimized canvas rendering, lazy loading, smooth 60fps animations
- **Scroll-Locked Experience**: User must complete the 600vh scroll sequence before reaching the rest of the site
- **Italian Craftsmanship**: Inspired by Pagani's attention to detail and artistry

## 🎯 Key Components Explained

### ZondaScrollCanvas
- Preloads all 240 frames on mount
- Maps `scrollYProgress` (0 to 1) to frame index (0 to 239)
- Renders with High-DPI support for crystal-clear visuals on Retina displays
- Uses `object-fit: contain` logic for responsive sizing

### ZondaExperience
- **Phase 1 (0-33%)**: Hero section with title, price, CTAs
- **Phase 2 (33-66%)**: Design features and carbon fiber details
- **Phase 3 (66-100%)**: Engine specs and AMG V12 power
- All animations driven by the same `scrollYProgress` MotionValue for perfect sync

### Master Scroll Architecture
- `app/page.tsx` owns the `useScroll` hook
- Single source of truth prevents desync between canvas and text
- 600vh tall container creates the extended scroll experience

## 🔧 Customization

### Change Colors
Edit `tailwind.config.ts`:
```typescript
colors: {
  'pagani-black': '#1a1a1a',
  'pagani-gold': '#D4AF37',
  'bright-gold': '#FFD700',
  'carbon-gray': '#2a2a2a',
}
```

### Change Content
Edit `data/carData.ts` to update all text, specs, and features.

### Use Different Image Sequence
Replace images in `PAGANI FRAMES/` and update the `totalFrames` prop in `app/page.tsx`.

## 📸 Image Sequence

The project includes 240 high-quality frames of a rotating Pagani Zonda R. The naming convention is:
- `ezgif-frame-001.jpg` to `ezgif-frame-240.jpg`

Ensure images are optimized for web to maintain smooth scrolling performance.

## 🌐 Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari 14+, Chrome Mobile)

## 📄 License

This is a showcase project. Pagani and Zonda R are trademarks of Pagani Automobili S.p.A.

---

**Built with ❤️ and Italian Engineering** 🇮🇹
