# 🚀 SETUP GUIDE - PAGANI ZONDA R WEBSITE

## Step 1: Install Node.js

Since Node.js is not currently installed on your system, you need to install it first.

### Option A: Using Homebrew (Recommended for Mac)

```bash
# Install Homebrew if you don't have it
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node.js
brew install node

# Verify installation
node --version
npm --version
```

### Option B: Download from Official Website

1. Visit https://nodejs.org/
2. Download the LTS version (recommended)
3. Run the installer
4. Verify installation by opening Terminal and running:
   ```bash
   node --version
   npm --version
   ```

## Step 2: Install Project Dependencies

Once Node.js is installed, navigate to the project directory and install dependencies:

```bash
cd "/Users/muhammedishraqm/Desktop/PAGANI WEBSITE"
npm install
```

This will install:
- Next.js 15
- React 19
- Framer Motion
- Tailwind CSS v4
- TypeScript
- And all other dependencies

## Step 3: Run the Development Server

```bash
npm run dev
```

The site will be available at http://localhost:3000

## Step 4: Build for Production (Optional)

```bash
npm run build
npm start
```

## 🎯 What You'll See

1. **Navbar** - Premium glassmorphism navbar with gold accents
2. **Scroll Sequence** - 240 frames of rotating Pagani Zonda R
3. **Three Phases**:
   - **Hero (0-33% scroll)**: Title, price, CTAs
   - **Design (33-66% scroll)**: Carbon fiber features
   - **Engine (66-100% scroll)**: V12 specifications
4. **Specs Grid** - Technical specifications
5. **Features** - Key features with icons
6. **Footer** - Premium footer with contact info

## 🔧 Troubleshooting

### Issue: Port 3000 already in use
```bash
# Kill the process using port 3000
lsof -ti:3000 | xargs kill -9

# Or use a different port
npm run dev -- -p 3001
```

### Issue: Images not loading
- Ensure all 240 frames are in `PAGANI FRAMES/` folder
- File names should be: `ezgif-frame-001.jpg` to `ezgif-frame-240.jpg`

### Issue: Slow scrolling
- This is normal on first load while images are being loaded
- Once all 240 frames are cached, scrolling will be smooth
- For production, consider converting images to WebP format

## 📊 Performance Tips

1. **Optimize Images**: Convert JPG to WebP for smaller file sizes
2. **Enable Caching**: Images will be cached after first load
3. **Use Chrome DevTools**: Monitor performance with Performance tab

## 🎨 Customization

See the main README.md for customization options.

---

**Ready to Experience Italian Engineering? Install Node.js and run `npm install` followed by `npm run dev`!** 🏎️
