import type { Metadata } from "next";
import { Orbitron, Rajdhani } from "next/font/google";
import "./globals.css";

const orbitron = Orbitron({
    subsets: ["latin"],
    weight: ["400", "500", "600", "700", "800", "900"],
    variable: "--font-orbitron",
    display: "swap",
});

const rajdhani = Rajdhani({
    subsets: ["latin"],
    weight: ["300", "400", "500", "600", "700"],
    variable: "--font-rajdhani",
    display: "swap",
});

export const metadata: Metadata = {
    title: "Pagani Zonda R | Ultimate Track Machine",
    description: "Experience the Pagani Zonda R - 750 HP of pure Italian engineering. A masterpiece of carbon fiber and Mercedes-AMG V12 power.",
    keywords: ["Pagani", "Zonda R", "Supercar", "Track Car", "Italian Luxury"],
    viewport: "width=device-width, initial-scale=1",
    themeColor: "#1a1a1a",
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" className={`${orbitron.variable} ${rajdhani.variable}`}>
            <body className="font-rajdhani antialiased">
                {children}
            </body>
        </html>
    );
}
