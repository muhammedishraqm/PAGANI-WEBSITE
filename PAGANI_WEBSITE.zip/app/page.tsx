"use client";

import { useRef } from "react";
import { useScroll } from "framer-motion";
import Navbar from "@/components/Navbar";
import ZondaScrollCanvas from "@/components/ZondaScrollCanvas";
import ZondaExperience from "@/components/ZondaExperience";
import SpecsGrid from "@/components/SpecsGrid";
import Features from "@/components/Features";
import Footer from "@/components/Footer";

export default function Home() {
    const containerRef = useRef<HTMLDivElement>(null);

    // Master scroll control - tracks the 600vh container
    const { scrollYProgress } = useScroll({
        target: containerRef,
        offset: ["start start", "end end"],
    });

    return (
        <main className="bg-pagani-black">
            <Navbar />

            {/* SCROLL SEQUENCE SECTION (600vh locked container) */}
            <section
                ref={containerRef}
                id="hero"
                className="h-[600vh] relative"
            >
                {/* Sticky Viewport - This stays fixed while user scrolls through 600vh */}
                <div className="sticky top-0 h-screen w-full overflow-hidden bg-pagani-black">
                    {/* Background: Scroll-controlled Canvas (z-0) */}
                    <div className="absolute inset-0 z-0">
                        <ZondaScrollCanvas
                            scrollYProgress={scrollYProgress}
                            totalFrames={240}
                            imageFolderPath="/images/zonda-sequence"
                        />
                    </div>

                    {/* Foreground: HUD Text Overlay (z-10) */}
                    <div className="absolute inset-0 z-10">
                        <ZondaExperience scrollYProgress={scrollYProgress} />
                    </div>

                    {/* Gradient Vignette for Depth */}
                    <div className="absolute inset-0 z-5 pointer-events-none">
                        <div className="absolute inset-0 bg-gradient-to-t from-pagani-black/80 via-transparent to-pagani-black/40" />
                        <div className="absolute inset-0 bg-gradient-to-r from-pagani-black/30 via-transparent to-pagani-black/30" />
                    </div>

                    {/* Progress Indicator */}
                    <div className="absolute bottom-8 right-8 z-20 pointer-events-none">
                        <div className="flex flex-col items-end gap-2">
                            <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-white/50">
                                SCROLL PROGRESS
                            </span>
                            <div className="w-1 h-32 bg-white/10 rounded-full overflow-hidden">
                                <div
                                    className="w-full bg-pagani-gold rounded-full transition-all duration-100"
                                    style={{
                                        height: `${scrollYProgress.get() * 100}%`,
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* REST OF THE SITE (Scrolls naturally after sequence completes) */}
            <div className="relative z-20 bg-pagani-black">
                <SpecsGrid />
                <Features />
                <Footer />
            </div>
        </main>
    );
}
