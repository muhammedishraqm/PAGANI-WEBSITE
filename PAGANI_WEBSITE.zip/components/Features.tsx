"use client";

import { motion } from "framer-motion";
import { carData } from "@/data/carData";

export default function Features() {
    const fadeInUp = {
        hidden: { opacity: 0, y: 60 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: { delay: i * 0.15, duration: 0.6 },
        }),
    };

    return (
        <section className="relative py-20 lg:py-32 bg-gradient-to-b from-pagani-black to-carbon-gray">
            <div className="max-w-7xl mx-auto px-6 lg:px-12">
                {/* Section Header */}
                <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.3 }}
                    className="text-center mb-16"
                >
                    <motion.div
                        variants={fadeInUp}
                        custom={0}
                        className="inline-block mb-4 px-6 py-2 border border-pagani-gold/30 bg-pagani-black/60 backdrop-blur-sm"
                    >
                        <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold">
                            ENGINEERING EXCELLENCE
                        </span>
                    </motion.div>
                    <motion.h2
                        variants={fadeInUp}
                        custom={1}
                        className="font-orbitron font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tight text-white text-glow"
                    >
                        KEY FEATURES
                    </motion.h2>
                </motion.div>

                {/* Features Grid */}
                <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.2 }}
                    className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
                >
                    {carData.features.map((feature, index) => (
                        <motion.div
                            key={index}
                            variants={fadeInUp}
                            custom={index}
                            className="group relative p-8 border border-pagani-gold/30 bg-pagani-black/60 backdrop-blur-sm hover:border-pagani-gold hover:bg-pagani-black/80 transition-all duration-500 hover-gold-glow overflow-hidden"
                        >
                            {/* Icon */}
                            <div className="text-6xl mb-6 group-hover:scale-110 transition-transform duration-500">
                                {feature.icon}
                            </div>

                            {/* Title */}
                            <h3 className="font-orbitron font-bold text-lg sm:text-xl text-pagani-gold mb-3 tracking-wide">
                                {feature.title}
                            </h3>

                            {/* Description */}
                            <p className="font-rajdhani font-light text-sm text-white/70 leading-relaxed">
                                {feature.description}
                            </p>

                            {/* Hover Effect Line */}
                            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-pagani-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
                        </motion.div>
                    ))}
                </motion.div>
            </div>
        </section>
    );
}
