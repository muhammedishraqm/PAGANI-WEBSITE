"use client";

import { motion } from "framer-motion";

export default function Footer() {
    const currentYear = new Date().getFullYear();

    return (
        <footer className="relative bg-pagani-black border-t border-pagani-gold/20 py-12 lg:py-16">
            <div className="max-w-7xl mx-auto px-6 lg:px-12">
                <div className="grid md:grid-cols-3 gap-12 mb-12">
                    {/* Brand */}
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-pagani-gold rounded-sm flex items-center justify-center">
                                <span className="text-pagani-black font-orbitron font-black text-xl">
                                    P
                                </span>
                            </div>
                            <div className="flex flex-col">
                                <span className="font-orbitron font-bold text-base tracking-[0.2em] text-pagani-gold">
                                    PAGANI
                                </span>
                                <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-white/70">
                                    AUTOMOBILI
                                </span>
                            </div>
                        </div>
                        <p className="font-rajdhani font-light text-sm text-white/60 leading-relaxed">
                            Handcrafted in Modena, Italy. Each Pagani is a work of art, a symphony of passion, innovation, and uncompromising excellence.
                        </p>
                    </div>

                    {/* Quick Links */}
                    <div>
                        <h3 className="font-orbitron font-bold text-sm tracking-[0.2em] text-pagani-gold mb-4">
                            QUICK LINKS
                        </h3>
                        <ul className="space-y-2 font-rajdhani font-light text-sm">
                            <li>
                                <a href="#hero" className="text-white/60 hover:text-pagani-gold transition-colors duration-300">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#design" className="text-white/60 hover:text-pagani-gold transition-colors duration-300">
                                    Design
                                </a>
                            </li>
                            <li>
                                <a href="#engine" className="text-white/60 hover:text-pagani-gold transition-colors duration-300">
                                    Engine
                                </a>
                            </li>
                            <li>
                                <a href="#specs" className="text-white/60 hover:text-pagani-gold transition-colors duration-300">
                                    Specifications
                                </a>
                            </li>
                        </ul>
                    </div>

                    {/* Contact */}
                    <div>
                        <h3 className="font-orbitron font-bold text-sm tracking-[0.2em] text-pagani-gold mb-4">
                            CONTACT
                        </h3>
                        <ul className="space-y-2 font-rajdhani font-light text-sm text-white/60">
                            <li>Via dell&apos;Artigianato, 5</li>
                            <li>41018 San Cesario sul Panaro (MO)</li>
                            <li>Italy</li>
                            <li className="pt-2">
                                <a href="tel:+390593579" className="hover:text-pagani-gold transition-colors duration-300">
                                    +39 059 3579
                                </a>
                            </li>
                            <li>
                                <a href="mailto:info@pagani.com" className="hover:text-pagani-gold transition-colors duration-300">
                                    info@pagani.com
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="pt-8 border-t border-pagani-gold/10">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="font-rajdhani font-light text-xs text-white/50">
                            © {currentYear} Pagani Automobili S.p.A. All rights reserved.
                        </p>
                        <div className="flex gap-6 font-rajdhani font-light text-xs">
                            <a href="#" className="text-white/50 hover:text-pagani-gold transition-colors duration-300">
                                Privacy Policy
                            </a>
                            <a href="#" className="text-white/50 hover:text-pagani-gold transition-colors duration-300">
                                Terms of Service
                            </a>
                            <a href="#" className="text-white/50 hover:text-pagani-gold transition-colors duration-300">
                                Cookie Policy
                            </a>
                        </div>
                    </div>
                </div>

                {/* Decorative Line */}
                <motion.div
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, ease: "easeInOut" }}
                    className="h-px bg-gradient-to-r from-transparent via-pagani-gold to-transparent mt-8"
                />
            </div>
        </footer>
    );
}
