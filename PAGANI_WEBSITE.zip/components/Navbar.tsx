"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useState, useEffect } from "react";

export default function Navbar() {
    const [scrolled, setScrolled] = useState(false);
    const { scrollY } = useScroll();

    const backgroundColor = useTransform(
        scrollY,
        [0, 100],
        ["rgba(26, 26, 26, 0)", "rgba(26, 26, 26, 0.9)"]
    );

    const backdropBlur = useTransform(
        scrollY,
        [0, 100],
        ["blur(0px)", "blur(10px)"]
    );

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <motion.nav
            style={{
                backgroundColor,
                backdropFilter: backdropBlur,
                WebkitBackdropFilter: backdropBlur,
            }}
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "border-b border-pagani-gold/20" : ""
                }`}
        >
            <div className="max-w-[1800px] mx-auto px-6 lg:px-12 py-4 lg:py-6">
                <div className="flex items-center justify-between">
                    {/* Logo */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="flex items-center gap-3"
                    >
                        <div className="w-10 h-10 lg:w-12 lg:h-12 bg-pagani-gold rounded-sm flex items-center justify-center">
                            <span className="text-pagani-black font-orbitron font-black text-lg lg:text-xl">
                                P
                            </span>
                        </div>
                        <div className="flex flex-col">
                            <span className="font-orbitron font-bold text-sm lg:text-base tracking-[0.2em] text-pagani-gold">
                                PAGANI
                            </span>
                            <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-white/70">
                                AUTOMOBILI
                            </span>
                        </div>
                    </motion.div>

                    {/* Navigation Links - Hidden on mobile */}
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.4 }}
                        className="hidden lg:flex items-center gap-10 font-rajdhani font-medium text-sm tracking-[0.15em]"
                    >
                        <a
                            href="#hero"
                            className="text-white/80 hover:text-pagani-gold transition-colors duration-300"
                        >
                            HOME
                        </a>
                        <a
                            href="#design"
                            className="text-white/80 hover:text-pagani-gold transition-colors duration-300"
                        >
                            DESIGN
                        </a>
                        <a
                            href="#engine"
                            className="text-white/80 hover:text-pagani-gold transition-colors duration-300"
                        >
                            ENGINE
                        </a>
                        <a
                            href="#specs"
                            className="text-white/80 hover:text-pagani-gold transition-colors duration-300"
                        >
                            SPECS
                        </a>
                    </motion.div>

                    {/* CTA Button */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.6, delay: 0.6 }}
                    >
                        <button className="relative group overflow-hidden px-6 lg:px-8 py-2.5 lg:py-3 border border-pagani-gold bg-transparent hover-gold-glow font-orbitron font-semibold text-xs lg:text-sm tracking-[0.2em] text-pagani-gold">
                            <span className="relative z-10">INQUIRE</span>
                            <motion.div
                                className="absolute inset-0 bg-pagani-gold"
                                initial={{ x: "-100%" }}
                                whileHover={{ x: 0 }}
                                transition={{ duration: 0.3 }}
                            />
                            <span className="absolute inset-0 flex items-center justify-center text-pagani-black font-orbitron font-semibold text-xs lg:text-sm tracking-[0.2em] opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20">
                                INQUIRE
                            </span>
                        </button>
                    </motion.div>
                </div>
            </div>
        </motion.nav>
    );
}
