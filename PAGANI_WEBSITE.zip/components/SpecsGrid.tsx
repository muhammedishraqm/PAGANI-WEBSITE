"use client";

import { motion } from "framer-motion";
import { carData } from "@/data/carData";

export default function SpecsGrid() {
    const fadeInUp = {
        hidden: { opacity: 0, y: 60 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: { delay: i * 0.1, duration: 0.6 },
        }),
    };

    return (
        <section id="specs" className="relative py-20 lg:py-32 bg-pagani-black">
            <div className="max-w-7xl mx-auto px-6 lg:px-12">
                {/* Section Header */}
                <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.3 }}
                    className="text-center mb-16"
                >
                    <motion.div
                        variants={fadeInUp}
                        custom={0}
                        className="inline-block mb-4 px-6 py-2 border border-pagani-gold/30 bg-carbon-gray/40 backdrop-blur-sm"
                    >
                        <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold">
                            TECHNICAL SPECIFICATIONS
                        </span>
                    </motion.div>
                    <motion.h2
                        variants={fadeInUp}
                        custom={1}
                        className="font-orbitron font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tight text-white text-glow"
                    >
                        THE NUMBERS
                    </motion.h2>
                </motion.div>

                {/* Specs Grid */}
                <div className="grid md:grid-cols-3 gap-8">
                    {/* Performance */}
                    <motion.div
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.3 }}
                        className="space-y-6"
                    >
                        <h3 className="font-orbitron font-bold text-2xl text-pagani-gold mb-6 tracking-wide">
                            PERFORMANCE
                        </h3>
                        {carData.specs.performance.map((item, index) => (
                            <motion.div
                                key={index}
                                variants={fadeInUp}
                                custom={index}
                                className="pb-4 border-b border-pagani-gold/20 hover:border-pagani-gold/50 transition-all duration-300"
                            >
                                <div className="font-rajdhani font-light text-sm tracking-[0.15em] text-white/50 mb-1">
                                    {item.label}
                                </div>
                                <div className="font-orbitron font-semibold text-lg text-white">
                                    {item.value}
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>

                    {/* Dimensions */}
                    <motion.div
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.3 }}
                        className="space-y-6"
                    >
                        <h3 className="font-orbitron font-bold text-2xl text-pagani-gold mb-6 tracking-wide">
                            DIMENSIONS
                        </h3>
                        {carData.specs.dimensions.map((item, index) => (
                            <motion.div
                                key={index}
                                variants={fadeInUp}
                                custom={index}
                                className="pb-4 border-b border-pagani-gold/20 hover:border-pagani-gold/50 transition-all duration-300"
                            >
                                <div className="font-rajdhani font-light text-sm tracking-[0.15em] text-white/50 mb-1">
                                    {item.label}
                                </div>
                                <div className="font-orbitron font-semibold text-lg text-white">
                                    {item.value}
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>

                    {/* Technical */}
                    <motion.div
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.3 }}
                        className="space-y-6"
                    >
                        <h3 className="font-orbitron font-bold text-2xl text-pagani-gold mb-6 tracking-wide">
                            TECHNICAL
                        </h3>
                        {carData.specs.technical.map((item, index) => (
                            <motion.div
                                key={index}
                                variants={fadeInUp}
                                custom={index}
                                className="pb-4 border-b border-pagani-gold/20 hover:border-pagani-gold/50 transition-all duration-300"
                            >
                                <div className="font-rajdhani font-light text-sm tracking-[0.15em] text-white/50 mb-1">
                                    {item.label}
                                </div>
                                <div className="font-orbitron font-semibold text-lg text-white">
                                    {item.value}
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                </div>
            </div>
        </section>
    );
}
