"use client";

import { motion, MotionValue, useTransform } from "framer-motion";
import { carData } from "@/data/carData";

interface ZondaExperienceProps {
    scrollYProgress: MotionValue<number>;
}

export default function ZondaExperience({ scrollYProgress }: ZondaExperienceProps) {
    // Phase 1: Hero (0% - 33%)
    const heroOpacity = useTransform(scrollYProgress, [0, 0.25, 0.33], [1, 1, 0]);
    const heroY = useTransform(scrollYProgress, [0, 0.33], [0, -50]);

    // Phase 2: Design (33% - 66%)
    const designOpacity = useTransform(
        scrollYProgress,
        [0.28, 0.33, 0.6, 0.66],
        [0, 1, 1, 0]
    );
    const designY = useTransform(scrollYProgress, [0.33, 0.66], [50, -50]);

    // Phase 3: Engine (66% - 100%)
    const engineOpacity = useTransform(
        scrollYProgress,
        [0.61, 0.66, 0.95, 1],
        [0, 1, 1, 1]
    );
    const engineY = useTransform(scrollYProgress, [0.66, 1], [50, 0]);

    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {/* PHASE 1: HERO (0-33%) */}
            <motion.div
                style={{ opacity: heroOpacity, y: heroY }}
                className="absolute inset-0 flex items-center justify-center"
            >
                <div className="max-w-5xl mx-auto px-6 lg:px-12 text-center">
                    {/* Top Badge */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.5 }}
                        className="inline-block mb-6 px-6 py-2 border border-pagani-gold/50 bg-pagani-black/40 backdrop-blur-md"
                    >
                        <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold">
                            TRACK-ONLY HYPERCAR
                        </span>
                    </motion.div>

                    {/* Main Title */}
                    <motion.h1
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.7 }}
                        className="font-orbitron font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl tracking-tight text-white text-glow mb-4"
                    >
                        {carData.hero.title}
                    </motion.h1>

                    {/* Subtitle */}
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.9 }}
                        className="font-rajdhani font-medium text-lg sm:text-xl md:text-2xl tracking-[0.2em] text-pagani-gold mb-3"
                    >
                        {carData.hero.subtitle}
                    </motion.p>

                    {/* Price */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 1.1 }}
                        className="mb-6"
                    >
                        <span className="font-orbitron font-bold text-2xl sm:text-3xl md:text-4xl text-bright-gold">
                            {carData.hero.price}
                        </span>
                    </motion.div>

                    {/* Description */}
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 1.3 }}
                        className="max-w-2xl mx-auto font-rajdhani font-light text-sm sm:text-base md:text-lg text-white/70 mb-8 leading-relaxed"
                    >
                        {carData.hero.description}
                    </motion.p>

                    {/* CTA Buttons */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 1.5 }}
                        className="flex flex-col sm:flex-row items-center justify-center gap-4 pointer-events-auto"
                    >
                        <button className="group relative overflow-hidden px-8 py-4 bg-pagani-gold hover:bg-bright-gold transition-all duration-300 font-orbitron font-bold text-sm tracking-[0.2em] text-pagani-black hover:scale-105">
                            {carData.hero.cta.primary}
                            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-pagani-black scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                        </button>
                        <button className="px-8 py-4 border border-pagani-gold hover:border-bright-gold hover-gold-glow transition-all duration-300 font-orbitron font-semibold text-sm tracking-[0.2em] text-pagani-gold hover:text-bright-gold">
                            {carData.hero.cta.secondary}
                        </button>
                    </motion.div>

                    {/* Scroll Indicator */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 1, delay: 2 }}
                        className="absolute bottom-10 left-1/2 -translate-x-1/2"
                    >
                        <div className="flex flex-col items-center gap-2">
                            <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-white/50">
                                SCROLL TO EXPLORE
                            </span>
                            <motion.div
                                animate={{ y: [0, 10, 0] }}
                                transition={{ duration: 1.5, repeat: Infinity }}
                                className="w-0.5 h-12 bg-gradient-to-b from-pagani-gold to-transparent"
                            />
                        </div>
                    </motion.div>
                </div>
            </motion.div>

            {/* PHASE 2: DESIGN (33-66%) */}
            <motion.div
                style={{ opacity: designOpacity, y: designY }}
                className="absolute inset-0 flex items-center"
            >
                <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        {/* Left: Title & Description */}
                        <div>
                            <div className="inline-block mb-4 px-4 py-1 border border-pagani-gold/30 bg-pagani-black/30 backdrop-blur-sm">
                                <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold">
                                    {carData.design.subtitle}
                                </span>
                            </div>
                            <h2 className="font-orbitron font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight text-white text-glow mb-6">
                                {carData.design.title}
                            </h2>
                            <p className="font-rajdhani font-light text-base md:text-lg text-white/70 leading-relaxed">
                                {carData.design.description}
                            </p>
                        </div>

                        {/* Right: Stats Grid */}
                        <div className="grid grid-cols-2 gap-6">
                            {carData.design.features.map((feature, index) => (
                                <div
                                    key={index}
                                    className="p-6 border border-pagani-gold/30 bg-carbon-gray/40 backdrop-blur-sm hover-gold-glow"
                                >
                                    <div className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold mb-2">
                                        {feature.label}
                                    </div>
                                    <div className="font-orbitron font-bold text-xl md:text-2xl text-white">
                                        {feature.value}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.div>

            {/* PHASE 3: ENGINE (66-100%) */}
            <motion.div
                style={{ opacity: engineOpacity, y: engineY }}
                className="absolute inset-0 flex items-center"
            >
                <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        {/* Left: Title & Description */}
                        <div>
                            <div className="inline-block mb-4 px-4 py-1 border border-pagani-gold/30 bg-pagani-black/30 backdrop-blur-sm">
                                <span className="font-rajdhani font-light text-xs tracking-[0.3em] text-pagani-gold">
                                    {carData.engine.subtitle}
                                </span>
                            </div>
                            <h2 className="font-orbitron font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight text-white text-glow mb-6">
                                {carData.engine.title}
                            </h2>
                            <p className="font-rajdhani font-light text-base md:text-lg text-white/70 leading-relaxed">
                                {carData.engine.description}
                            </p>
                        </div>

                        {/* Right: Engine Specs */}
                        <div className="space-y-4">
                            {carData.engine.specs.map((spec, index) => (
                                <div
                                    key={index}
                                    className="flex items-center justify-between p-4 border border-pagani-gold/20 bg-carbon-gray/40 backdrop-blur-sm hover:border-pagani-gold/50 transition-all duration-300"
                                >
                                    <span className="font-rajdhani font-light text-sm tracking-[0.2em] text-white/60">
                                        {spec.label}
                                    </span>
                                    <span className="font-orbitron font-bold text-lg md:text-xl text-pagani-gold">
                                        {spec.value}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
