"use client";

import { useEffect, useRef } from "react";
import { MotionValue, useTransform } from "framer-motion";

interface ZondaScrollCanvasProps {
    scrollYProgress: MotionValue<number>;
    totalFrames?: number;
    imageFolderPath?: string;
}

export default function ZondaScrollCanvas({
    scrollYProgress,
    totalFrames = 240,
    imageFolderPath = "/images/zonda-sequence",
}: ZondaScrollCanvasProps) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const imagesRef = useRef<HTMLImageElement[]>([]);
    const loadedRef = useRef(false);

    // Transform scroll progress (0 to 1) into frame index (0 to totalFrames - 1)
    const frameIndex = useTransform(
        scrollYProgress,
        [0, 1],
        [0, totalFrames - 1]
    );

    // Load all images
    useEffect(() => {
        if (loadedRef.current) return;

        const loadImages = async () => {
            const images: HTMLImageElement[] = [];
            const loadPromises: Promise<void>[] = [];

            for (let i = 1; i <= totalFrames; i++) {
                const img = new Image();
                const promise = new Promise<void>((resolve, reject) => {
                    img.onload = () => resolve();
                    img.onerror = () => {
                        console.error(`Failed to load image: ${i}`);
                        resolve(); // Continue loading other images
                    };
                });

                // Match the 1.jpg to 240.jpg naming
                img.src = `${imageFolderPath}/${i}.jpg`;
                images.push(img);
                loadPromises.push(promise);
            }

            await Promise.all(loadPromises);
            imagesRef.current = images;
            loadedRef.current = true;
            console.log(`✅ Loaded ${totalFrames} frames`);
        };

        loadImages();
    }, [totalFrames, imageFolderPath]);

    // Render canvas with high-DPI support
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        const updateCanvas = () => {
            const currentFrame = Math.round(frameIndex.get());
            const img = imagesRef.current[currentFrame];

            if (!img || !img.complete) return;

            // High-DPI support
            const dpr = window.devicePixelRatio || 1;
            const rect = canvas.getBoundingClientRect();

            // Set canvas size for retina displays
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;

            // Scale context for high resolution
            ctx.scale(dpr, dpr);

            // Set CSS size
            canvas.style.width = `${rect.width}px`;
            canvas.style.height = `${rect.height}px`;

            // Clear canvas
            ctx.clearRect(0, 0, rect.width, rect.height);

            // Calculate dimensions for object-fit: contain
            const imgRatio = img.width / img.height;
            const canvasRatio = rect.width / rect.height;

            let drawWidth = rect.width;
            let drawHeight = rect.height;
            let offsetX = 0;
            let offsetY = 0;

            if (canvasRatio > imgRatio) {
                // Canvas is wider - fit to height
                drawWidth = rect.height * imgRatio;
                offsetX = (rect.width - drawWidth) / 2;
            } else {
                // Canvas is taller - fit to width
                drawHeight = rect.width / imgRatio;
                offsetY = (rect.height - drawHeight) / 2;
            }

            // Draw image with object-fit contain logic
            ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
        };

        // Subscribe to frame changes
        const unsubscribe = frameIndex.on("change", updateCanvas);

        // Initial render
        updateCanvas();

        // Handle resize
        const handleResize = () => {
            updateCanvas();
        };

        window.addEventListener("resize", handleResize);

        return () => {
            unsubscribe();
            window.removeEventListener("resize", handleResize);
        };
    }, [frameIndex]);

    return (
        <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full object-contain"
            style={{ imageRendering: "high-quality" }}
        />
    );
}
