export const carData = {
    hero: {
        title: "PAGANI ZONDA R",
        subtitle: "ULTIMATE TRACK WEAPON",
        price: "€1,500,000",
        description: "Hand-crafted in Modena, Italy. A symphony of carbon fiber, AMG power, and Italian artistry.",
        cta: {
            primary: "INQUIRE NOW",
            secondary: "DOWNLOAD BROCHURE"
        }
    },
    design: {
        title: "DESIGN",
        subtitle: "SCULPTURAL PERFECTION",
        features: [
            {
                label: "MONOCOQUE",
                value: "Carbon-Titanium"
            },
            {
                label: "WEIGHT",
                value: "1,070 kg"
            },
            {
                label: "AERODYNAMICS",
                value: "Active Aero"
            },
            {
                label: "BODY",
                value: "100% Carbon Fiber"
            }
        ],
        description: "Every curve serves a purpose. Every surface optimized for maximum downforce. The Zonda R is not just fast—it's a masterpiece of aerodynamic engineering."
    },
    engine: {
        title: "ENGINE",
        subtitle: "AMG HEART",
        specs: [
            {
                label: "ENGINE",
                value: "6.0L V12"
            },
            {
                label: "POWER",
                value: "750 HP"
            },
            {
                label: "TORQUE",
                value: "710 N⋅m"
            },
            {
                label: "0-100 KM/H",
                value: "2.7s"
            },
            {
                label: "TOP SPEED",
                value: "350+ km/h"
            },
            {
                label: "REDLINE",
                value: "8,500 RPM"
            }
        ],
        description: "A Mercedes-AMG V12 masterpiece. Naturally aspirated fury delivering 750 horsepower of pure, unfiltered performance."
    },
    features: [
        {
            title: "CARBON FIBER MONOCOQUE",
            description: "The chassis is a carbon-titanium hybrid, lighter than air yet stronger than steel.",
            icon: "🏎️"
        },
        {
            title: "ACTIVE AERODYNAMICS",
            description: "Adaptive wing and diffuser generate over 1,500 kg of downforce at speed.",
            icon: "✈️"
        },
        {
            title: "BREMBO RACING BRAKES",
            description: "Carbon-ceramic discs with 6-piston calipers. Stop on a dime from any speed.",
            icon: "🛑"
        },
        {
            title: "BESPOKE INTERIOR",
            description: "Hand-stitched leather, machined aluminum, and a driving position designed for the track.",
            icon: "🎨"
        }
    ],
    specs: {
        performance: [
            { label: "Power", value: "750 HP @ 7,500 RPM" },
            { label: "Torque", value: "710 N⋅m @ 5,500 RPM" },
            { label: "0-100 km/h", value: "2.7 seconds" },
            { label: "Top Speed", value: "350+ km/h" },
            { label: "PowerWeight Ratio", value: "1.43 kg/HP" }
        ],
        dimensions: [
            { label: "Length", value: "4,395 mm" },
            { label: "Width", value: "2,055 mm" },
            { label: "Height", value: "1,141 mm" },
            { label: "Wheelbase", value: "2,730 mm" },
            { label: "Dry Weight", value: "1,070 kg" }
        ],
        technical: [
            { label: "Engine", value: "Mercedes-AMG M120 V12" },
            { label: "Displacement", value: "5,987 cc" },
            { label: "Transmission", value: "6-Speed Sequential" },
            { label: "Drive", value: "RWD" },
            { label: "Suspension", value: "Racing Pushrod" }
        ]
    }
};

export type CarData = typeof carData;
